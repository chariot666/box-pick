Run box_pick
============

1. Extract this zip.
2. Open Anaconda/Miniconda PowerShell in the extracted folder.
3. Activate the environment that has mujoco, pinocchio, numpy and opencv-python.

Example:

    conda activate pinocchio
    python box_pick.py

If cv2 is missing:

    pip install opencv-python

The script uses paths relative to this folder, so it does not need to be placed
at D:\thingscatch.

