"""Lightweight state-action critic for the MMK2 box-pick experiment.

Stage 1 deliberately keeps the analytical IK, collision checker and controller
in charge. Stage 2 adds short MuJoCo branch rollouts and learns to predict four
short-horizon outcomes from a
compact state/action vector:

* safety: no non-finger robot/package collision;
* four_finger_contact: all four finger pads carry load;
* transport_ready: safe bilateral grasp suitable for extraction.
* slot_ready: both open grippers safely straddle their intended package walls.

The JSONL format is intentionally simple so later work can replace the MLP with
a visual/latent world model without changing the simulator instrumentation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable
import uuid

import numpy as np


FEATURE_NAMES = (
    "stage_id",
    "stage_progress",
    "box_dx",
    "box_dy",
    "box_dz",
    "left_endpoint_dx",
    "left_endpoint_dy",
    "left_endpoint_dz",
    "right_endpoint_dx",
    "right_endpoint_dy",
    "right_endpoint_dz",
    "left_tracking_error",
    "right_tracking_error",
    "left_gripper_q",
    "right_gripper_q",
    "gripper_command",
    "slide_tracking_error",
    "left_slot_error",
    "right_slot_error",
    "endpoint_separation",
    "grasp_validated",
)
LABEL_NAMES = ("safe", "four_finger_contact", "transport_ready", "slot_ready")
# Version 3 changes `transport_ready`: it now requires a grasp that has
# survived physical transport with the package free in MuJoCo.  Version-2
# datasets may contain kinematic-attachment positives and must not be mixed.
FORMAT_VERSION = 3
TRANSPORT_SEMANTICS_VERSION = 2


class WAMCriticRecorder:
    def __init__(self, path: str | Path | None):
        self.path = Path(path).resolve() if path else None
        self.rows: list[dict] = []
        self.episode_id = uuid.uuid4().hex
        if self.path is not None and self.path.exists():
            first = next(
                (line for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()),
                None,
            )
            if first is not None and json.loads(first).get("version") != FORMAT_VERSION:
                raise ValueError(
                    "refusing to append physical-transport labels to a legacy WAM "
                    "dataset; choose a new --wam-dataset path"
                )

    def add(self, features: Iterable[float], labels: Iterable[float], metadata=None):
        if self.path is None:
            return
        features = [float(value) for value in features]
        labels = [float(value) for value in labels]
        if len(features) != len(FEATURE_NAMES):
            raise ValueError(f"expected {len(FEATURE_NAMES)} WAM features, got {len(features)}")
        if len(labels) != len(LABEL_NAMES):
            raise ValueError(f"expected {len(LABEL_NAMES)} WAM labels, got {len(labels)}")
        self.rows.append(
            {
                "version": FORMAT_VERSION,
                "features": features,
                "labels": labels,
                "metadata": {
                    "episode_id": self.episode_id,
                    "transport_semantics": "free_body_contact_friction_v2",
                    **dict(metadata or {}),
                },
            }
        )

    def flush(self, episode_success: bool):
        if self.path is None or not self.rows:
            return 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            for row in self.rows:
                row["metadata"]["episode_success"] = bool(episode_success)
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        count = len(self.rows)
        self.rows.clear()
        return count


def _load_rows(path: str | Path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("version") != FORMAT_VERSION:
                raise ValueError(
                    f"unsupported WAM dataset version at line {line_number}; "
                    "start a new dataset because transport_ready now means "
                    "free-body contact/friction transport"
                )
            if len(row["features"]) != len(FEATURE_NAMES):
                raise ValueError(f"invalid feature count at line {line_number}")
            rows.append(row)
    if not rows:
        raise ValueError(f"WAM dataset is empty: {path}")
    return rows


def _bootstrap_counterfactuals(x: np.ndarray, y: np.ndarray, seed: int):
    """Add bounded failure alternatives around real simulator observations.

    These are explicitly marked as bootstrap counterfactuals in the saved model.
    They prevent a first successful trajectory from producing an always-success
    classifier.  Future stages should replace them with randomized real rollouts.
    """
    rng = np.random.default_rng(seed)
    augmented_x = [x]
    augmented_y = [y]

    collision_x = x.copy()
    collision_x[:, FEATURE_NAMES.index("left_tracking_error")] += rng.uniform(0.15, 0.45, len(x))
    collision_x[:, FEATURE_NAMES.index("right_tracking_error")] += rng.uniform(0.15, 0.45, len(x))
    collision_x[:, FEATURE_NAMES.index("endpoint_separation")] *= 0.35
    collision_y = y.copy()
    collision_y[:, :] = 0.0
    augmented_x.append(collision_x)
    augmented_y.append(collision_y)

    contact_loss_x = x.copy()
    contact_loss_x[:, FEATURE_NAMES.index("left_slot_error")] += rng.choice((-1.0, 1.0), len(x)) * 0.08
    contact_loss_x[:, FEATURE_NAMES.index("right_slot_error")] += rng.choice((-1.0, 1.0), len(x)) * 0.08
    contact_loss_y = y.copy()
    contact_loss_y[:, 1:] = 0.0
    augmented_x.append(contact_loss_x)
    augmented_y.append(contact_loss_y)

    tracking_x = x.copy()
    tracking_x[:, FEATURE_NAMES.index("left_tracking_error")] += rng.uniform(0.35, 0.70, len(x))
    tracking_x[:, FEATURE_NAMES.index("right_tracking_error")] += rng.uniform(0.35, 0.70, len(x))
    tracking_y = y.copy()
    tracking_y[:, 2] = 0.0
    augmented_x.append(tracking_x)
    augmented_y.append(tracking_y)
    return np.concatenate(augmented_x), np.concatenate(augmented_y)


def train_critic(dataset_path, model_path, epochs=800, seed=7):
    import torch
    from torch import nn

    torch.manual_seed(seed)
    np.random.seed(seed)
    rows = _load_rows(dataset_path)
    x_real = np.asarray([row["features"] for row in rows], dtype=np.float32)
    y_real = np.asarray([row["labels"] for row in rows], dtype=np.float32)
    rng = np.random.default_rng(seed)
    episode_ids = np.asarray(
        [row.get("metadata", {}).get("episode_id", f"row-{index}") for index, row in enumerate(rows)]
    )
    unique_episodes = np.unique(episode_ids)
    shuffled_episodes = rng.permutation(unique_episodes)
    if len(shuffled_episodes) >= 2:
        episode_split = max(1, int(0.80 * len(shuffled_episodes)))
        episode_split = min(episode_split, len(shuffled_episodes) - 1)
        training_episodes = set(shuffled_episodes[:episode_split].tolist())
        real_train_idx = np.flatnonzero(
            np.asarray([episode in training_episodes for episode in episode_ids])
        )
        real_validation_idx = np.flatnonzero(
            np.asarray([episode not in training_episodes for episode in episode_ids])
        )
    else:
        real_order = rng.permutation(len(x_real))
        real_split = max(1, int(0.80 * len(real_order)))
        real_train_idx = real_order[:real_split]
        real_validation_idx = real_order[real_split:]
    if not len(real_validation_idx):
        real_validation_idx = real_train_idx
    # Split real observations first. Counterfactual siblings of a validation
    # observation must never leak into training.
    x_train, y_train = _bootstrap_counterfactuals(
        x_real[real_train_idx], y_real[real_train_idx], seed
    )
    x_validation, y_validation = _bootstrap_counterfactuals(
        x_real[real_validation_idx], y_real[real_validation_idx], seed + 1
    )
    mean = x_train.mean(axis=0)
    std = x_train.std(axis=0)
    std[std < 1.0e-5] = 1.0

    class CriticMLP(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(len(FEATURE_NAMES), 48),
                nn.SiLU(),
                nn.Linear(48, 32),
                nn.SiLU(),
                nn.Linear(32, len(LABEL_NAMES)),
            )

        def forward(self, values):
            return self.net(values)

    model = CriticMLP()
    optimizer = torch.optim.AdamW(model.parameters(), lr=2.5e-3, weight_decay=1.0e-4)
    x_tensor = torch.from_numpy((x_train - mean) / std)
    y_tensor = torch.from_numpy(y_train)
    positives = y_tensor.sum(dim=0)
    negatives = len(y_tensor) - positives
    pos_weight = torch.clamp(
        negatives / torch.clamp(positives, min=1.0), 0.5, 12.0
    )
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    for _ in range(int(epochs)):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss = loss_fn(model(x_tensor), y_tensor)
        loss.backward()
        optimizer.step()

    model.eval()
    with torch.no_grad():
        validation_tensor = torch.from_numpy((x_validation - mean) / std)
        probabilities = torch.sigmoid(model(validation_tensor)).numpy()
    predictions = probabilities >= 0.5
    truth = y_validation >= 0.5
    accuracy = (predictions == truth).mean(axis=0)
    brier = ((probabilities - y_validation) ** 2).mean(axis=0)
    true_positive = np.logical_and(predictions, truth).sum(axis=0)
    false_positive = np.logical_and(predictions, ~truth).sum(axis=0)
    false_negative = np.logical_and(~predictions, truth).sum(axis=0)
    precision = true_positive / np.maximum(1, true_positive + false_positive)
    recall = true_positive / np.maximum(1, true_positive + false_negative)

    model_path = Path(model_path).resolve()
    model_path.parent.mkdir(parents=True, exist_ok=True)
    state_dict = model.state_dict()
    portable_weights = {
        key.removeprefix("net.").replace(".", "_"): value.detach().cpu().numpy()
        for key, value in state_dict.items()
    }
    np.savez_compressed(
        model_path,
        format_version=np.asarray([FORMAT_VERSION], dtype=np.int64),
        transport_semantics_version=np.asarray(
            [TRANSPORT_SEMANTICS_VERSION], dtype=np.int64
        ),
        feature_names=np.asarray(FEATURE_NAMES),
        label_names=np.asarray(LABEL_NAMES),
        mean=mean,
        std=std,
        real_samples=np.asarray([len(x_real)], dtype=np.int64),
        training_samples=np.asarray([len(x_train)], dtype=np.int64),
        validation_samples=np.asarray([len(x_validation)], dtype=np.int64),
        bootstrap_counterfactuals=np.asarray([1], dtype=np.int8),
        episode_group_split=np.asarray([int(len(unique_episodes) >= 2)], dtype=np.int8),
        episode_count=np.asarray([len(unique_episodes)], dtype=np.int64),
        validation_accuracy=accuracy,
        validation_brier=brier,
        validation_precision=precision,
        validation_recall=recall,
        **portable_weights,
    )
    # np.savez appends .npz to string paths without that suffix. Honour the
    # exact CLI path so --wam-model can load it without guessing.
    appended_path = Path(str(model_path) + ".npz")
    if appended_path.exists() and appended_path != model_path:
        appended_path.replace(model_path)
    metrics = {
        "real_samples": int(len(x_real)),
        "training_samples": int(len(x_train)),
        "validation_samples": int(len(x_validation)),
        "validation_accuracy": dict(zip(LABEL_NAMES, accuracy.round(4).tolist())),
        "validation_precision": dict(zip(LABEL_NAMES, precision.round(4).tolist())),
        "validation_recall": dict(zip(LABEL_NAMES, recall.round(4).tolist())),
        "validation_brier": dict(zip(LABEL_NAMES, brier.round(4).tolist())),
        "model_path": str(model_path),
    }
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return metrics


class WAMCritic:
    def __init__(self, model_path: str | Path):
        checkpoint = np.load(Path(model_path), allow_pickle=False)
        if tuple(checkpoint["feature_names"].tolist()) != FEATURE_NAMES:
            raise ValueError("WAM model feature schema does not match this code")
        self.label_names = tuple(checkpoint["label_names"].tolist())
        self.transport_semantics_version = int(
            checkpoint["transport_semantics_version"][0]
            if "transport_semantics_version" in checkpoint.files
            else 1
        )
        self.legacy_transport_labels = self.transport_semantics_version < 2
        self.mean = np.asarray(checkpoint["mean"], dtype=np.float32)
        self.std = np.asarray(checkpoint["std"], dtype=np.float32)
        self.weights = {
            name: np.asarray(checkpoint[name], dtype=np.float32)
            for name in ("0_weight", "0_bias", "2_weight", "2_bias", "4_weight", "4_bias")
        }
        self.metadata = {
            "real_samples": int(checkpoint["real_samples"][0]),
            "training_samples": int(checkpoint["training_samples"][0]),
            "bootstrap_counterfactuals": bool(checkpoint["bootstrap_counterfactuals"][0]),
        }

    @staticmethod
    def _silu(values):
        return values / (1.0 + np.exp(-np.clip(values, -40.0, 40.0)))

    def predict(self, features: Iterable[float]):
        values = np.asarray(list(features), dtype=np.float32)
        if values.shape != (len(FEATURE_NAMES),):
            raise ValueError("invalid WAM feature vector")
        hidden1 = self._silu(self.weights["0_weight"] @ ((values - self.mean) / self.std) + self.weights["0_bias"])
        hidden2 = self._silu(self.weights["2_weight"] @ hidden1 + self.weights["2_bias"])
        logits = self.weights["4_weight"] @ hidden2 + self.weights["4_bias"]
        probabilities = 1.0 / (1.0 + np.exp(-np.clip(logits, -40.0, 40.0)))
        return dict(zip(self.label_names, probabilities.astype(float)))


def main():
    parser = argparse.ArgumentParser(description="Train the stage-1 WAM critic")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--epochs", type=int, default=800)
    args = parser.parse_args()
    train_critic(args.dataset, args.model, epochs=args.epochs)


if __name__ == "__main__":
    main()
