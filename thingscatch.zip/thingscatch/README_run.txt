运行方法：
1. 把压缩包解压到 D:\，保证路径是 D:\thingscatch\box_pick.py
2. conda env create -f environment.yml
3. conda activate pinocchio
4. python box_pick.py

如果不解压到 D:\thingscatch，需要运行时手动传 --discoverse-root / --mjcf / --urdf。