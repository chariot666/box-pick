"""Action-conditioned WAM critic trained from MuJoCo branch rollouts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from wam_critic import FEATURE_NAMES, LABEL_NAMES, TRANSPORT_SEMANTICS_VERSION


ACTION_NAMES = (
    "candidate_dx", "candidate_left_dz", "candidate_right_dz",
    "mass_scale", "friction_scale",
)
INPUT_NAMES = FEATURE_NAMES + ACTION_NAMES


def _branch_rows(path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            row = json.loads(line)
            metadata = row.get("metadata", {})
            if metadata.get("source") != "mujoco_branch_rollout":
                continue
            pre_state = metadata.get("pre_state_features")
            action = metadata.get("action_offset_m")
            scene = metadata.get("scene_randomization", {})
            if pre_state is None or action is None:
                continue
            context = [scene.get("mass_scale", 1.0), scene.get("friction_scale", 1.0)]
            rows.append((row, np.asarray([*pre_state, *action, *context], dtype=np.float32)))
    if not rows:
        raise ValueError("dataset has no stage-3 branch rows with pre_state_features")
    return rows


def train_action_critic(dataset_path, model_path, epochs=300, seed=17):
    import torch
    from torch import nn

    torch.manual_seed(seed)
    records = _branch_rows(dataset_path)
    x = np.stack([values for _, values in records])
    y = np.asarray([row["labels"] for row, _ in records], dtype=np.float32)
    episodes = np.asarray([
        row.get("metadata", {}).get("episode_id", f"row-{index}")
        for index, (row, _) in enumerate(records)
    ])
    unique = np.unique(episodes)
    order = np.random.default_rng(seed).permutation(unique)
    if len(order) >= 2:
        split = min(max(1, int(0.8 * len(order))), len(order) - 1)
        train_episodes = set(order[:split].tolist())
        train_idx = np.flatnonzero([episode in train_episodes for episode in episodes])
        val_idx = np.flatnonzero([episode not in train_episodes for episode in episodes])
    else:
        indices = np.random.default_rng(seed).permutation(len(x))
        split = max(1, int(0.8 * len(indices)))
        train_idx, val_idx = indices[:split], indices[split:]
        if not len(val_idx):
            val_idx = train_idx
    mean, std = x[train_idx].mean(0), x[train_idx].std(0)
    std[std < 1.0e-5] = 1.0

    model = nn.Sequential(
        nn.Linear(len(INPUT_NAMES), 64), nn.SiLU(),
        nn.Linear(64, 32), nn.SiLU(),
        nn.Linear(32, len(LABEL_NAMES)),
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=2.0e-3, weight_decay=1e-4)
    x_train = torch.from_numpy((x[train_idx] - mean) / std)
    y_train = torch.from_numpy(y[train_idx])
    # Rare unsafe rollouts are important and receive balanced positive weights.
    positives = y_train.sum(0)
    negatives = len(y_train) - positives
    pos_weight = torch.clamp(negatives / torch.clamp(positives, min=1.0), 0.25, 20.0)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    for _ in range(int(epochs)):
        optimizer.zero_grad(set_to_none=True)
        loss = loss_fn(model(x_train), y_train)
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        probability = torch.sigmoid(
            model(torch.from_numpy((x[val_idx] - mean) / std))
        ).numpy()
    accuracy = ((probability >= 0.5) == (y[val_idx] >= 0.5)).mean(0)
    brier = ((probability - y[val_idx]) ** 2).mean(0)
    weights = {
        key.replace(".", "_"): value.detach().numpy()
        for key, value in model.state_dict().items()
    }
    path = Path(model_path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        input_names=np.asarray(INPUT_NAMES), label_names=np.asarray(LABEL_NAMES),
        mean=mean, std=std, episode_count=np.asarray([len(unique)]),
        training_samples=np.asarray([len(train_idx)]),
        validation_samples=np.asarray([len(val_idx)]),
        transport_semantics_version=np.asarray(
            [TRANSPORT_SEMANTICS_VERSION], dtype=np.int64
        ),
        validation_accuracy=accuracy, validation_brier=brier, **weights,
    )
    appended = Path(str(path) + ".npz")
    if appended.exists() and appended != path:
        appended.replace(path)
    metrics = {
        "branch_samples": len(records), "episodes": len(unique),
        "training_samples": len(train_idx), "validation_samples": len(val_idx),
        "validation_accuracy": dict(zip(LABEL_NAMES, accuracy.round(4).tolist())),
        "validation_brier": dict(zip(LABEL_NAMES, brier.round(4).tolist())),
        "model_path": str(path),
    }
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return metrics


class ActionWAMCritic:
    def __init__(self, model_path):
        data = np.load(model_path, allow_pickle=False)
        self.labels = tuple(data["label_names"].tolist())
        self.transport_semantics_version = int(
            data["transport_semantics_version"][0]
            if "transport_semantics_version" in data.files
            else 1
        )
        self.legacy_transport_labels = self.transport_semantics_version < 2
        self.mean = data["mean"].astype(np.float32)
        self.std = data["std"].astype(np.float32)
        self.weights = {
            name: data[name].astype(np.float32)
            for name in ("0_weight", "0_bias", "2_weight", "2_bias", "4_weight", "4_bias")
        }

    @staticmethod
    def _silu(values):
        return values / (1.0 + np.exp(-np.clip(values, -40, 40)))

    def predict(self, state_features, action_offset, scene_context=(1.0, 1.0)):
        values = np.asarray(
            [*state_features, *action_offset, *scene_context], dtype=np.float32
        )
        values = (values - self.mean) / self.std
        values = self._silu(self.weights["0_weight"] @ values + self.weights["0_bias"])
        values = self._silu(self.weights["2_weight"] @ values + self.weights["2_bias"])
        logits = self.weights["4_weight"] @ values + self.weights["4_bias"]
        probability = 1.0 / (1.0 + np.exp(-np.clip(logits, -40, 40)))
        return dict(zip(self.labels, probability.astype(float)))
