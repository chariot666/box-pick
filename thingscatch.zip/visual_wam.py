"""Lightweight two-frame visual/state fusion critic for WAM stage 4."""

from __future__ import annotations

import json
from pathlib import Path
import uuid

import cv2
import numpy as np

from wam_critic import FEATURE_NAMES, LABEL_NAMES, TRANSPORT_SEMANTICS_VERSION


GRID_SIZE = (12, 9)
VISUAL_FEATURE_COUNT = GRID_SIZE[0] * GRID_SIZE[1] * 6


def encode_frame_pair(previous, current):
    """Fixed visual encoder: low-resolution RGB appearance plus frame delta."""
    current_small = cv2.resize(np.asarray(current), GRID_SIZE, interpolation=cv2.INTER_AREA)
    if previous is None:
        previous_small = current_small
    else:
        previous_small = cv2.resize(np.asarray(previous), GRID_SIZE, interpolation=cv2.INTER_AREA)
    current_float = current_small.astype(np.float32) / 255.0
    delta = (current_small.astype(np.float32) - previous_small.astype(np.float32)) / 255.0
    return np.concatenate((current_float.reshape(-1), delta.reshape(-1))).astype(np.float32)


class VisualWAMRecorder:
    def __init__(self, directory):
        self.directory = Path(directory).resolve() if directory else None
        self.episode_id = uuid.uuid4().hex
        self.previous = None
        self.rows = []
        if self.directory is not None:
            existing = self.directory / "visual_samples.jsonl"
            if existing.exists():
                first = next(
                    (line for line in existing.read_text(encoding="utf-8").splitlines() if line.strip()),
                    None,
                )
                if first is not None and json.loads(first).get("version") != 2:
                    raise ValueError(
                        "refusing to mix legacy visual labels with physical-transport "
                        "labels; choose a new --visual-dataset-dir"
                    )

    def add(self, image, state_features, labels, metadata=None):
        if self.directory is None or image is None:
            return
        visual = encode_frame_pair(self.previous, image)
        self.previous = np.asarray(image).copy()
        self.rows.append({
            "version": 2,
            "visual_features": visual.tolist(),
            "state_features": np.asarray(state_features, dtype=float).tolist(),
            "labels": np.asarray(labels, dtype=float).tolist(),
            "metadata": {
                "episode_id": self.episode_id,
                "transport_semantics": "free_body_contact_friction_v2",
                **dict(metadata or {}),
            },
        })

    def flush(self, episode_success):
        if self.directory is None or not self.rows:
            return 0
        self.directory.mkdir(parents=True, exist_ok=True)
        path = self.directory / "visual_samples.jsonl"
        with path.open("a", encoding="utf-8") as stream:
            for row in self.rows:
                row["metadata"]["episode_success"] = bool(episode_success)
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        count = len(self.rows)
        self.rows.clear()
        return count


def train_visual_critic(dataset_dir, model_path, epochs=260, seed=29):
    import torch
    from torch import nn

    path = Path(dataset_dir) / "visual_samples.jsonl"
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        raise ValueError(f"visual dataset is empty: {path}")
    if any(row.get("version") != 2 for row in rows):
        raise ValueError(
            "visual dataset uses legacy attachment-era transport labels; "
            "collect a new version-2 visual dataset"
        )
    visual = np.asarray([row["visual_features"] for row in rows], dtype=np.float32)
    state = np.asarray([row["state_features"] for row in rows], dtype=np.float32)
    x = np.concatenate((visual, state), axis=1)
    y = np.asarray([row["labels"] for row in rows], dtype=np.float32)
    episodes = np.asarray([row["metadata"]["episode_id"] for row in rows])
    unique = np.unique(episodes)
    order = np.random.default_rng(seed).permutation(unique)
    if len(order) >= 2:
        split = min(max(1, int(0.8 * len(order))), len(order) - 1)
        train_episodes = set(order[:split].tolist())
        train_idx = np.flatnonzero([episode in train_episodes for episode in episodes])
        val_idx = np.flatnonzero([episode not in train_episodes for episode in episodes])
    else:
        indices = np.random.default_rng(seed).permutation(len(x))
        split = max(1, int(0.8 * len(indices)))
        train_idx, val_idx = indices[:split], indices[split:]
        if not len(val_idx):
            val_idx = train_idx
    mean, std = x[train_idx].mean(0), x[train_idx].std(0)
    std[std < 1e-5] = 1.0
    model = nn.Sequential(
        nn.Linear(x.shape[1], 96), nn.SiLU(), nn.Dropout(0.08),
        nn.Linear(96, 48), nn.SiLU(), nn.Linear(48, len(LABEL_NAMES)),
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=1.8e-3, weight_decay=2e-4)
    loss_fn = nn.BCEWithLogitsLoss()
    xt = torch.from_numpy((x[train_idx] - mean) / std)
    yt = torch.from_numpy(y[train_idx])
    for _ in range(int(epochs)):
        model.train(); optimizer.zero_grad(set_to_none=True)
        loss = loss_fn(model(xt), yt); loss.backward(); optimizer.step()
    model.eval()
    with torch.no_grad():
        probability = torch.sigmoid(model(torch.from_numpy((x[val_idx] - mean) / std))).numpy()
    accuracy = ((probability >= .5) == (y[val_idx] >= .5)).mean(0)
    brier = ((probability - y[val_idx]) ** 2).mean(0)
    weights = {key.replace(".", "_"): value.detach().numpy() for key, value in model.state_dict().items()}
    output = Path(model_path).resolve(); output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output, mean=mean, std=std, label_names=np.asarray(LABEL_NAMES),
        transport_semantics_version=np.asarray(
            [TRANSPORT_SEMANTICS_VERSION], dtype=np.int64
        ),
        episode_count=np.asarray([len(unique)]), validation_accuracy=accuracy,
        validation_brier=brier, **weights,
    )
    appended = Path(str(output) + ".npz")
    if appended.exists() and appended != output:
        appended.replace(output)
    metrics = {
        "samples": len(rows), "episodes": len(unique),
        "validation_accuracy": dict(zip(LABEL_NAMES, accuracy.round(4).tolist())),
        "validation_brier": dict(zip(LABEL_NAMES, brier.round(4).tolist())),
        "model_path": str(output),
    }
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return metrics


class VisualWAMCritic:
    def __init__(self, model_path):
        data = np.load(model_path, allow_pickle=False)
        self.mean, self.std = data["mean"], data["std"]
        self.labels = tuple(data["label_names"].tolist())
        self.transport_semantics_version = int(
            data["transport_semantics_version"][0]
            if "transport_semantics_version" in data.files
            else 1
        )
        self.legacy_transport_labels = self.transport_semantics_version < 2
        self.weights = {name: data[name] for name in ("0_weight", "0_bias", "3_weight", "3_bias", "5_weight", "5_bias")}
        self.previous = None

    @staticmethod
    def _silu(values):
        return values / (1.0 + np.exp(-np.clip(values, -40, 40)))

    def predict(self, image, state_features):
        visual = encode_frame_pair(self.previous, image)
        self.previous = np.asarray(image).copy()
        values = (np.r_[visual, state_features] - self.mean) / self.std
        values = self._silu(self.weights["0_weight"] @ values + self.weights["0_bias"])
        values = self._silu(self.weights["3_weight"] @ values + self.weights["3_bias"])
        logits = self.weights["5_weight"] @ values + self.weights["5_bias"]
        probability = 1.0 / (1.0 + np.exp(-np.clip(logits, -40, 40)))
        return dict(zip(self.labels, probability.astype(float)))
